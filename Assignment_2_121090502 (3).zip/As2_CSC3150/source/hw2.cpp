#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <curses.h>
#include <termios.h>
#include <fcntl.h>
#include <iostream>

#define ROW 10
#define COLUMN 50

struct Node
{
    int x, y;
    Node(int _x, int _y) : x(_x), y(_y){};
    Node(){};
} frog;

pthread_mutex_t lock;
char map[ROW + 2][COLUMN];
int is_alive; // 1 if the game not end, 0 if game ends
int flag;     // 1 if win 0 if lose -1 if quit

// Determine a keyboard is hit or not. If yes, return 1. If not, return 0.
int kbhit(void)
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);

    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);

    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);

    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

void game_exit()
{
    pthread_exit(NULL);
}

void check_status(int flag)
{
    if (flag == 1)
    {
        printf("You win the game!!\n");
    }
    else if (flag == 0)
    {
        printf("You lose the game!!\n");
    }
    else if (flag == -1)
    {
        printf("You exit the game.\n");
    }
    else if (flag == -2)
    {
    }
    else
    {
        printf("Check_status fault: flag fault.\n");
    }
}

void win()
{
    flag = 1;
    is_alive = 0;
    // clear screen]
    system("clear");
    check_status(flag);
    game_exit();
}

void fail()
{
    flag = 0;
    is_alive = 0;
    // clear screen]
    system("clear");
    check_status(flag);
    game_exit();
}

void quit()
{
    flag = -1;
    is_alive = 0;
    // clear screen]
    system("clear");
    check_status(flag);
    game_exit();
}

void *frog_move(void *t)
{
    char keyboard;
    while (is_alive)
    {

        if (kbhit() != 0)
        {
            pthread_mutex_lock(&lock);
            keyboard = getchar();

            if (keyboard == 'w' || keyboard == 'W')
            {
                map[frog.x][frog.y] = ' ';
                if (frog.x - 1 > 0)
                {
                    frog.x -= 1;
                    if (map[frog.x][frog.y] == '=')
                    {
                        map[frog.x][frog.y] = '0';
                        map[ROW][frog.y] = '|';
                    }
                    else
                    {
                        flag = 0;
                        fail();
                    }
                }
                else if (frog.x - 1 == 0)
                {
                    flag = 1;
                    win();
                }
            }
            else if (keyboard == 'a' || keyboard == 'A')
            {
                map[frog.x][frog.y] = ' ';
                if (frog.y == 0)
                {
                    flag = 0;
                    fail();
                }
                if (frog.x == ROW)
                {
                    map[frog.x][frog.y] = '|';
                }
                if (frog.y > 0)
                {
                    frog.y -= 1;
                    if (map[frog.x][frog.y] == '=' || map[frog.x][frog.y] == '|')
                    {
                        map[frog.x][frog.y] = '0';
                    }
                    else
                    {
                        flag = 0;
                        fail();
                    }
                }
                else
                {
                    flag = 0;
                    fail();
                }
            }
            else if (keyboard == 's' || keyboard == 'S')
            {
                map[frog.x][frog.y] = ' ';
                if (frog.x == ROW)
                {
                    flag = 0;
                    fail();
                }
                if (frog.x <= ROW)
                {
                    frog.x += 1;
                    if (map[frog.x][frog.y] == '=' || map[frog.x][frog.y] == '|')
                    {
                        map[frog.x][frog.y] = '0';
                    }
                    else
                    {
                        flag = 0;
                        fail();
                    }
                }
                else
                {
                    flag = 0;
                    fail();
                }
            }
            else if (keyboard == 'd' || keyboard == 'D')
            {
                map[frog.x][frog.y] = ' ';
                if (frog.y == COLUMN)
                {
                    flag = 0;
                    fail();
                }
                if (frog.x == ROW)
                {
                    map[frog.x][frog.y] = '|';
                }
                if (frog.y < COLUMN - 1)
                {
                    frog.y += 1;
                    if (map[frog.x][frog.y] == '=' || map[frog.x][frog.y] == '|')
                    {
                        map[frog.x][frog.y] = '0';
                    }
                    else
                    {
                        flag = 0;
                        fail();
                    }
                }
                else
                {
                    flag = 0;
                    fail();
                }
            }
            else if (keyboard == 'q')
            {
                flag = -1;
                quit();
            }

            pthread_mutex_unlock(&lock);
        }
    }
    usleep(75000);
}

void *logs_move(void *t)
{
    int logs_head[ROW];
    int directions[ROW];
    int HEAD_startPos;
    for (int i = 1; i < ROW; i++)
    {
        if (i % 2 == 0)
        {
            directions[i] = 1; // 2468
        }
        else
        {
            directions[i] = -1;
        } // 13579 left; 2468 right ;
        HEAD_startPos = (rand() % 50);
        logs_head[i] = HEAD_startPos;
    } // INIT OVER

    while (is_alive)
    {
        pthread_mutex_lock(&lock);
        system("clear");

        for (int i = 1; i < ROW; ++i)
        {
            logs_head[i] = logs_head[i] + directions[i];
            logs_head[i] = (logs_head[i] + 50) % 50;
            if (i % 2 == 1)
            { // 13579: dir= -1
                for (int j = 0; j < 15; j++)
                {
                    map[i][(logs_head[i] + j - directions[i] + 50) % 50] = ' ';
                    map[i][(logs_head[i] + j + 50) % 50] = '=';
                }
            }
            else
            { // 2468 dir= 1
                for (int j = 0; j < 15; j++)
                {
                    map[i][(logs_head[i] - j - directions[i] + 50) % 50] = ' ';
                    map[i][(logs_head[i] - j + 50) % 50] = '=';
                }
            }
        }
        if (frog.x > 0 && frog.x < ROW)
        {
            if (frog.x % 2 == 1)
                frog.y--;
            else
                frog.y++;
        }
        map[frog.x][frog.y] = '0';

        for (int i = 0; i <= ROW; ++i)
        {
            for (int j = 0; j < COLUMN; ++j)
            {
                putchar(map[i][j]);
            }
            putchar('\n');
        }
        pthread_mutex_unlock(&lock);
        check_status(flag);
        usleep(75000);
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    // Initialize the river map and frog's starting position
    memset(map, 0, sizeof(map));
    int i, j;
    for (i = 1; i < ROW; ++i)
    {
        for (j = 0; j < COLUMN - 1; ++j)
            map[i][j] = ' ';
    }

    for (j = 0; j < COLUMN; ++j)
        map[ROW][j] = map[0][j] = '|';

    frog = Node(ROW, (COLUMN - 1) / 2);
    map[frog.x][frog.y] = '0';

    // Print the map into screen
    // system("clear");
    for (i = 0; i <= ROW; ++i)
        puts(map[i]);

    /*  Create pthreads for wood move and frog control.  */
    pthread_mutex_init(&lock, NULL);
    is_alive = 1;
    flag = -2;
    pthread_t frog_thread, log_thread;

    pthread_create(&frog_thread, NULL, frog_move, NULL);
    pthread_create(&log_thread, NULL, logs_move, NULL);

    pthread_join(frog_thread, NULL);
    pthread_join(log_thread, NULL);
    /*  Display the output for user: win, lose or quit.  */

    pthread_mutex_destroy(&lock);
    return 0;
}
